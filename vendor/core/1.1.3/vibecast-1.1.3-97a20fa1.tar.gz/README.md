# Exact protected Core renderer1.1.3 package

Supplying revision: 97a20fa17d60aa32cf92dc106707d70540ee479e. Brand2.0.1 official small input is authenticated.
Original1.1.2 pins stay immutable. Build/verifier uses the original included source.
Rebuild twice byte-equal; receiver import tested in a disposable private root only.
Source protected; separate Finalization recorded outside this immutable build-time package.
Consumer adoption/publication, live HA/CAF, native/installed/physical TV stay open.
Full canonical Brand2.0.1 assets and generator/font are provided in a separate exact-source ZIP.
